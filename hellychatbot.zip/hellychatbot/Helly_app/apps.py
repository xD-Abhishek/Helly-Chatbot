from django.apps import AppConfig


class ChatgptAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Helly_app'

# register the helly to app in settings.py