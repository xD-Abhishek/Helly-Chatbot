import os

from dotenv import load_dotenv

load_dotenv()

GOOGLE_API_KEY = os.getenv("AIzaSyDwub8jiBS9c85GeysV-vxmnCaCn8UvyVk")
